<?php

require 'libs/Smarty.class.php';

$smarty = new Smarty;
$smarty->debugging = true;

$smarty->assign("title", "La boutique Chez Pupuce", true);
$smarty->assign("Products", array(
		"cat1" => array(
			"prod1" => array("id"=>1, "name"=>"truc", "img"=>"truc.gif", "prix"=>12), 
			"prod2" => array("id"=>2, "name"=>"Machin", "img"=>"machin.jpg", "prix"=>22), 
			"prod3"  => array("id"=>3, "name"=>"chose", "img"=>"chose.jpg", "prix"=>32)
		), 
		"cat2" => array(
			"prod4" => array("id"=>4, "name"=>"bidulle", "img"=>"bidule.jpg", "prix"=>67), 
			"prod5" => array("id"=>5, "name"=>"chouette", "img"=>"chouette.jpg", "prix"=>56), 
			"prod6"  => array("id"=>6, "name"=>"objet", "img"=>"objet.jpg", "prix"=>356)
		),
		"cat3" => array(
			"prod7" => array("id"=>7, "name"=>"Chien", "img"=>"chien.jpg", "prix"=>99999), 
			"prod8" => array("id"=>8, "name"=>"Chat", "img"=>"chat.jpg", "prix"=>99998), 
			"prod9"  => array("id"=>9, "name"=>"Canari", "img"=>"canari.jpg", "prix"=>89657885)
		)));

$smarty->display('template/index.tpl');
